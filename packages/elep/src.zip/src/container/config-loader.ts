import * as esbuild from 'esbuild';
import * as fsp from 'node:fs/promises';
import * as path from 'node:path';
import { LRUCache } from 'lru-cache';
import type { ElepConfig } from './config-types.js';

/**
 * A special sentinel object to indicate a cached lookup that found no config file.
 * This is used to differentiate a true cache miss from a known absence of a config file.
 * @internal
 */
const CONFIG_NOT_FOUND = Symbol('CONFIG_NOT_FOUND');

/**
 * Manages the finding, just-in-time compilation, loading, and caching of
 * `elep.config.ts` files for plugins.
 * @internal
 */
export class ConfigLoader {
  // Caches the parsed configuration object for each plugin.
  // The key is the absolute path to the plugin's root directory.
  // We use a union with a unique symbol to handle caching the "not found" state.
  private readonly cache = new LRUCache<string, ElepConfig | typeof CONFIG_NOT_FOUND>({
    max: 100, // Cache configurations for up to 100 plugins
  });

  /**
   * Creates an instance of ConfigLoader.
   * @param rootPath The absolute path to the container's root directory.
   */
  constructor(private readonly rootPath: string) {}

  /**
   * Resolves the path to a plugin's configuration file, checking for supported extensions
   * in order of priority.
   * @param pluginAbsolutePath The absolute path to the plugin's root directory.
   * @returns A promise that resolves to the full path of the config file, or null if none is found.
   */
  private async resolveConfigFile(pluginAbsolutePath: string): Promise<string | null> {
    const extensions = ['ts', 'js']; // Priority: .ts is checked before .js
    for (const ext of extensions) {
      const configPath = path.join(pluginAbsolutePath, `elep.config.${ext}`);
      try {
        await fsp.access(configPath, fsp.constants.F_OK);
        return configPath; // Return the first one found
      } catch {
        // Continue to the next extension
      }
    }
    return null; // No config file found with any supported extension
  }

  /**
   * Loads the configuration for a specific plugin.
   * It returns a cached version if available, otherwise it compiles and loads the file.
   *
   * @param pluginPath The path of the plugin relative to the container's root.
   * @returns A promise that resolves to the parsed `ElepConfig` object,
   *          or `null` if no configuration file is found.
   * @throws An error if the configuration file exists but fails to load or parse.
   */
  public async load(pluginPath: string): Promise<ElepConfig | null> {
    const pluginAbsolutePath = path.resolve(this.rootPath, pluginPath);

    const cached = this.cache.get(pluginAbsolutePath);
    if (cached !== undefined) {
      // If the cache holds the sentinel, it means we know the file doesn't exist.
      return cached === CONFIG_NOT_FOUND ? null : cached;
    }

    const configPath = await this.resolveConfigFile(pluginAbsolutePath);

    if (configPath === null) {
      this.cache.set(pluginAbsolutePath, CONFIG_NOT_FOUND);
      return null;
    }

    try {
      // esbuild handles both .ts and .js files seamlessly.
      const result = await esbuild.build({
        entryPoints: [configPath], // Pass the found config path
        bundle: true,
        format: 'esm',
        platform: 'node',
        write: false,
        target: `node${process.versions.node}`,
      });

      const [outputFile] = result.outputFiles;
      if (!outputFile) {
        throw new Error('esbuild compilation did not produce an output file.');
      }

      const code = outputFile.text;
      const dataUri = `data:text/javascript;base64,${Buffer.from(code).toString('base64')}`;

      const module = await import(`${dataUri}?v=${Date.now()}`);
      
      const config = module.default as ElepConfig;
      if (!config) {
        throw new Error(`Config file at '${configPath}' must have a default export.`);
      }

      this.cache.set(pluginAbsolutePath, config);
      return config;
    } catch (error: any) {
      throw new Error(`Error loading ${path.basename(configPath)} for plugin '${pluginPath}': ${error.message}`);
    }
  }
}