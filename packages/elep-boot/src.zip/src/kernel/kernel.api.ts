import type { ECore } from '@eleplug/elep';
import type { Pin } from '@eleplug/erpc';

// 这个文件应该被核心插件（例如 appCore）在其 tsconfig.json 的 "include" 中引用
// 以获得类型提示和检查。
declare module '@eleplug/anvil' {
  interface PluginApiMap {
    // 定义了名为 '__kernel' 的插件，其 API 类型是一个被 Pin 的 ECore 实例。
    '__kernel': Pin<ECore>;
  }
}