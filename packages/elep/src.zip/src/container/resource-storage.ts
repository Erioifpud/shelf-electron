import type { ResourceGetResponse } from "@eleplug/esys";
import * as fs from "node:fs";
import * as fsp from "node:fs/promises";
import * as path from "node:path";
import * as mime from "mime-types";
import { Readable, Writable } from "node:stream";
import { LRUCache } from "lru-cache";
import micromatch from "micromatch";
import type { IPluginLoader } from "./plugin-loader.js";
import type { ElepConfig } from "./config-types.js";
import type { PluginRuntime } from "./plugin-runtime.js";

/**
 * A special sentinel object to indicate a cached lookup that found no config file.
 * This is used to differentiate a true cache miss from a known absence of a config file.
 * @internal
 */
const CONFIG_NOT_FOUND = Symbol("CONFIG_NOT_FOUND");

/**
 * Defines the abstract interface for a resource storage backend.
 * This contract allows for different storage implementations (e.g., file system, cloud storage)
 * to be used interchangeably by a Container.
 */
export interface IResourceStorage {
  /**
   * Retrieves a resource's content as a readable stream.
   * @param relativePath The path to the resource, relative to the storage root.
   * @returns A Promise that resolves to a `ResourceGetResponse` object.
   * @throws An error if the resource is not found or is a directory.
   */
  get(relativePath: string): Promise<ResourceGetResponse>;

  /**
   * Writes or overwrites a resource from a readable stream.
   * It will create parent directories if they do not exist.
   * @param relativePath The path to the resource, relative to the storage root.
   * @param stream A `ReadableStream` containing the new content for the resource.
   * @returns A Promise that resolves when the write operation is complete.
   */
  put(relativePath: string, stream: ReadableStream): Promise<void>;

  /**
   * Lists the contents of a directory.
   * @param relativePath The path to the directory, relative to the storage root.
   * @returns A Promise that resolves to an array of file and directory names.
   * @throws An error if the path is not a directory or does not exist.
   */
  list(relativePath: string): Promise<string[]>;
}

/**
 * An `IResourceStorage` implementation that uses the local file system.
 * It provides secure, sandboxed access to a specific root directory.
 * In development mode, it delegates to an active `DevPlugin` before
 * falling back to the filesystem.
 */
export class FileResourceStorage implements IResourceStorage {
  /**
   * Caches loaded plugin configurations to avoid repeated file parsing and compilation.
   * The key is the plugin's path within the container.
   */
  private readonly configCache: LRUCache<
    string,
    ElepConfig | typeof CONFIG_NOT_FOUND
  >;
  private readonly loader: IPluginLoader;
  private readonly getRuntime: (
    pluginPath: string
  ) => PluginRuntime | undefined;

  /**
   * Creates an instance of FileResourceStorage.
   * @param rootPath The absolute path to the root directory that this storage instance manages.
   *                 The directory will be created if it doesn't exist.
   * @param loader An instance of IPluginLoader used to fetch plugin configurations.
   * @param getRuntime A function to look up the active runtime for a plugin, enabling dev hooks.
   */
  constructor(
    private readonly rootPath: string,
    loader: IPluginLoader,
    getRuntime: (pluginPath: string) => PluginRuntime | undefined
  ) {
    this.loader = loader;
    this.getRuntime = getRuntime;
    this.configCache = new LRUCache({
      max: 100, // Cache config for up to 100 plugins
    });

    if (!fs.existsSync(this.rootPath)) {
      fs.mkdirSync(this.rootPath, { recursive: true });
    }
  }

  /**
   * {@inheritDoc IResourceStorage.get}
   */
  public async get(relativePath: string): Promise<ResourceGetResponse> {
    const { pluginPath, resourcePathInPlugin, absolutePath } =
      this.parseAndSecurePath(relativePath);

    // --- Development Mode Hook ---
    const runtime = this.getRuntime(pluginPath);
    if (runtime?.activeDevPlugin?.get) {
      try {
        // Attempt to serve the resource using the active dev plugin.
        return await runtime.activeDevPlugin.get(resourcePathInPlugin);
      } catch (devError: any) {
        // Log the error for debugging but fall through to the default file access.
        // This allows dev servers to only handle specific paths (e.g., source files)
        // while letting other resources (e.g., data files) be served normally.
        console.debug(
          `[FileResourceStorage] Dev hook for '${relativePath}' failed or did not handle the request, falling back to filesystem. Error: ${devError.message}`
        );
      }
    }

    // --- Default Filesystem Access ---
    try {
      const stats = await fsp.stat(absolutePath);
      if (stats.isDirectory()) {
        throw new Error(`Path is a directory, not a file: "${relativePath}"`);
      }

      const mimeType = await this.getMimeType(absolutePath, relativePath);
      const nodeStream = fs.createReadStream(absolutePath);
      const body = Readable.toWeb(nodeStream) as ReadableStream<Uint8Array>;

      return { body, mimeType };
    } catch (error: any) {
      if (error.code === "ENOENT") {
        throw new Error(`Resource not found: "${relativePath}"`);
      }
      throw new Error(
        `Failed to get resource "${relativePath}": ${error.message}`
      );
    }
  }

  /**
   * {@inheritDoc IResourceStorage.put}
   */
  public async put(
    relativePath: string,
    stream: ReadableStream
  ): Promise<void> {
    const { pluginPath, resourcePathInPlugin, absolutePath } =
      this.parseAndSecurePath(relativePath);

    // --- Development Mode Hook ---
    const runtime = this.getRuntime(pluginPath);
    if (runtime?.activeDevPlugin?.put) {
      try {
        await runtime.activeDevPlugin.put(resourcePathInPlugin, stream);
        return; // If handled by the dev plugin, we're done.
      } catch (devError: any) {
        console.debug(
          `[FileResourceStorage] Dev hook 'put' for '${relativePath}' failed, falling back. Error: ${devError.message}`
        );
      }
    }

    // --- Default Filesystem Access ---
    try {
      await fsp.mkdir(path.dirname(absolutePath), { recursive: true });
      const nodeWritable = fs.createWriteStream(absolutePath);
      const webWritableStream = Writable.toWeb(nodeWritable);

      await stream.pipeTo(webWritableStream);
    } catch (error: any) {
      throw new Error(
        `Failed to write resource to "${relativePath}": ${error.message}`
      );
    }
  }

  /**
   * {@inheritDoc IResourceStorage.list}
   */
  public async list(relativePath: string): Promise<string[]> {
    const { pluginPath, resourcePathInPlugin, absolutePath } =
      this.parseAndSecurePath(relativePath);

    // --- Development Mode Hook ---
    const runtime = this.getRuntime(pluginPath);
    if (runtime?.activeDevPlugin?.list) {
      try {
        return await runtime.activeDevPlugin.list(resourcePathInPlugin);
      } catch (devError: any) {
        console.debug(
          `[FileResourceStorage] Dev hook 'list' for '${relativePath}' failed, falling back. Error: ${devError.message}`
        );
      }
    }

    // --- Default Filesystem Access ---
    try {
      const stats = await fsp.stat(absolutePath);
      if (!stats.isDirectory()) {
        throw new Error(`Path is not a directory: "${relativePath}"`);
      }
      return await fsp.readdir(absolutePath);
    } catch (error: any) {
      if (error.code === "ENOENT") {
        throw new Error(`Directory not found: "${relativePath}"`);
      }
      throw new Error(
        `Failed to list directory "${relativePath}": ${error.message}`
      );
    }
  }

  /**
   * Parses and secures a relative path, splitting it into its plugin and resource components.
   * @param relativePath The path relative to the container root.
   * @returns An object containing the secure absolute path and its components.
   * @private
   */
  private parseAndSecurePath(relativePath: string) {
    const absolutePath = this.secureJoin(this.rootPath, relativePath);
    const pathSegments = relativePath.split(path.sep);
    const pluginPath = pathSegments[0] || "";
    const resourcePathInPlugin = pathSegments.slice(1).join(path.sep);
    return { pluginPath, resourcePathInPlugin, absolutePath };
  }

  /**
   * Securely joins path segments and ensures the resulting path is within the container's root.
   * This is a critical security function to prevent path traversal attacks.
   * @param segments - Path segments to join.
   * @returns The resolved, absolute path.
   * @throws An error if the resolved path attempts to escape the root directory.
   * @private
   */
  private secureJoin(...segments: string[]): string {
    const resolvedPath = path.resolve(...segments);
    const relative = path.relative(this.rootPath, resolvedPath);

    if (relative.startsWith("..") || path.isAbsolute(relative)) {
      throw new Error(
        `Path traversal detected. Attempted to access a path outside of the container root: ${resolvedPath}`
      );
    }
    return resolvedPath;
  }

  /**
   * Determines the MIME type for a file by first checking for a match in the plugin's
   * `elep.config.ts` and then falling back to a standard lookup.
   * @param absolutePath - The absolute path to the file on the filesystem.
   * @param relativePath - The path to the resource relative to the container's root.
   * @returns The MIME type string, or undefined if not determinable.
   * @private
   */
  private async getMimeType(
    absolutePath: string,
    relativePath: string
  ): Promise<string | undefined> {
    const { pluginPath, resourcePathInPlugin } =
      this.parseAndSecurePath(relativePath);

    if (!pluginPath || resourcePathInPlugin === undefined) {
      return mime.lookup(absolutePath) || undefined;
    }

    let configOrSentinel = this.configCache.get(pluginPath);
    if (configOrSentinel === undefined) {
      const loadedConfig = await this.loader.loadConfig(pluginPath);
      configOrSentinel =
        loadedConfig === null ? CONFIG_NOT_FOUND : loadedConfig;
      this.configCache.set(pluginPath, configOrSentinel);
    }

    const config =
      configOrSentinel === CONFIG_NOT_FOUND ? null : configOrSentinel;

    if (config?.mimes) {
      for (const pattern in config.mimes) {
        if (micromatch.isMatch(resourcePathInPlugin, pattern)) {
          return config.mimes[pattern];
        }
      }
    }

    const fallbackMime = mime.lookup(absolutePath);
    return fallbackMime ? fallbackMime : undefined;
  }
}
