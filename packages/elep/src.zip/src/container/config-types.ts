import type { DevPlugin } from './dev-plugin-types.js';

/**
 * Defines the structure of the elep.config.ts configuration file.
 * This interface can be extended in the future to support more plugin-level configurations.
 */
export interface ElepConfig {
  /**
   * A map of MIME type overrides.
   *
   * The keys are `micromatch` glob patterns relative to the plugin's root directory.
   * The values are the corresponding MIME type strings.
   * The first pattern that matches a resource path will be used.
   *
   * @example
   * {
   *   "assets/logo.svg": "image/svg+xml",
   *   "dist/**\/*.js": "text/javascript"
   * }
   */
  mimes?: Record<string, string>;

  /**
   * Development mode configuration.
   *
   * This property is only loaded and executed when the container is started in
   * development mode. It should be an object that conforms to the `DevPlugin`
   * interface, allowing integration with external development servers like Vite.
   *
   * @example
   * import { viteDevPlugin } from 'elep-vite-adapter';
   *
   * export default defineConfig({
   *   dev: viteDevPlugin(),
   * });
   */
  dev?: DevPlugin;
}

/**
 * A helper function to provide type safety and autocompletion for `elep.config.ts` files.
 * It's an identity function that simply returns the config object it receives,
 * allowing TypeScript to infer the types correctly.
 *
 * @param config The Elep configuration object.
 * @example
 * // my-plugin/elep.config.ts
 * import { defineConfig } from '@eleplug/elep';
 *
 * export default defineConfig({
 *   mimes: {
 *     '**\/*.ui.js': 'text/javascript',
 *   }
 * });
 */
export function defineConfig(config: ElepConfig): ElepConfig {
  return config;
}