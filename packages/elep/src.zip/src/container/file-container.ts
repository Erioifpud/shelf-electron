import { type Bus } from "@eleplug/ebus";
import {
  type Container,
  type PluginManifest,
  type ResourceGetResponse,
} from "@eleplug/esys";
import {
  FileResourceStorage,
  type IResourceStorage,
} from "./resource-storage.js";
import { FilePluginLoader, type IPluginLoader } from "./plugin-loader.js";
import { PluginRuntime } from "./plugin-runtime.js";

/**
 * Defines the configuration options for creating a FileContainer.
 * This allows for dependency injection, making the container highly configurable and testable.
 */
export interface FileContainerOptions {
  /** The unique name for this container instance. */
  name: string;
  /** The system's EBUS instance, passed to plugins for communication. */
  bus: Bus;
  /** The absolute path to the root directory for this container's plugins and resources. */
  rootPath: string;
  /**
   * Optional. A custom implementation of the resource storage interface.
   * If not provided, a default `FileResourceStorage` instance will be created.
   */
  storage?: IResourceStorage;
  /**
   * Optional. A custom implementation of the plugin loader interface.
   * If not provided, a default `FilePluginLoader` instance will be created.
   */
  loader?: IPluginLoader;
  /**
   * Optional. If true, the container will run in development mode,
   * enabling features like live-reloading via `elep.config.ts`.
   * @default false
   */
  devMode?: boolean;
}

/**
 * A container that loads plugins and resources from the local file system.
 *
 * This class acts as a coordinator, delegating specific tasks to specialized modules:
 * - `IResourceStorage`: Handles all file system I/O, with hooks for dev mode.
 * - `IPluginLoader`: Handles finding and loading plugin code and configuration.
 * - `PluginRuntime`: Manages the lifecycle of each active plugin.
 */
export class FileContainer implements Container {
  private readonly storage: IResourceStorage;
  private readonly loader: IPluginLoader;
  private readonly runtimes = new Map<string, PluginRuntime>();
  private readonly containerName: string;
  private readonly bus: Bus;
  private readonly devMode: boolean;

  /**
   * Creates an instance of FileContainer.
   * @param options The configuration for the container.
   */
  constructor(options: FileContainerOptions) {
    this.containerName = options.name;
    this.bus = options.bus;
    this.devMode = options.devMode ?? false;

    // Use provided implementations or instantiate defaults.
    this.loader = options.loader ?? new FilePluginLoader(options.rootPath);
    this.storage =
      options.storage ??
      new FileResourceStorage(
        options.rootPath,
        this.loader,
        (pluginPath: string) => this.runtimes.get(pluginPath)
      );
  }

  /**
   * Retrieves an existing PluginRuntime instance for a given path or creates a new one.
   * @param pluginPath The path of the plugin within the container.
   * @returns The `PluginRuntime` instance for the specified plugin.
   * @private
   */
  private getOrCreateRuntime(pluginPath: string): PluginRuntime {
    if (!this.runtimes.has(pluginPath)) {
      const runtime = new PluginRuntime({
        bus: this.bus,
        containerName: this.containerName,
        pluginPath: pluginPath,
        loader: this.loader,
        devMode: this.devMode,
      });
      this.runtimes.set(pluginPath, runtime);
    }
    return this.runtimes.get(pluginPath)!;
  }

  /**
   * Implements the `Container.plugins` interface.
   */
  public readonly plugins = {
    /**
     * Activates a plugin by delegating to its `PluginRuntime` instance.
     * The runtime will internally source the plugin's groups from its manifest.
     * @param pluginPath The path of the plugin to activate.
     */
    activate: async (pluginPath: string): Promise<void> => {
      const runtime = this.getOrCreateRuntime(pluginPath);
      await runtime.activate();
    },

    /**
     * Deactivates a plugin by delegating to its `PluginRuntime` instance and then
     * removing the instance from management.
     * @param pluginPath The path of the plugin to deactivate.
     */
    deactivate: async (pluginPath: string): Promise<void> => {
      const runtime = this.runtimes.get(pluginPath);
      if (runtime) {
        await runtime.deactivate();
        this.runtimes.delete(pluginPath);
      }
    },

    /**
     * Retrieves a plugin's manifest by delegating to the plugin loader.
     * @param pluginPath The path of the plugin.
     * @returns A `PluginManifest` object.
     */
    manifest: (pluginPath: string): Promise<PluginManifest> => {
      return this.loader.loadManifest(pluginPath);
    },
  };

  /**
   * Implements the `Container.resources` interface by delegating all calls
   * directly to the configured storage backend.
   */
  public readonly resources = {
    get: (resourcePath: string): Promise<ResourceGetResponse> => {
      return this.storage.get(resourcePath);
    },
    put: (resourcePath: string, stream: ReadableStream): Promise<void> => {
      return this.storage.put(resourcePath, stream);
    },
    list: (dirPath: string): Promise<string[]> => {
      return this.storage.list(dirPath);
    },
  };

  /**
   * Gracefully closes the container by deactivating all running plugins.
   */
  public async close(): Promise<void> {
    const deactivationPromises = Array.from(this.runtimes.values()).map(
      (runtime) => runtime.deactivate()
    );
    await Promise.allSettled(deactivationPromises);
    this.runtimes.clear();
  }
}