import { app } from 'electron';
import * as path from 'node:path';
import * as fs from 'node:fs/promises';
import { Bootloader, LifecycleEvent, Registry } from '@eleplug/esys';
import { ECore, FileContainer } from '@eleplug/elep';
import { loadConfig, type AppConfig } from './config.js';
import { createKernelRouter } from './kernel/router.js';

/**
 * The application context, passed through the bootloader lifecycle.
 */
interface AppContext {
  config: Required<AppConfig>;
  appRoot: string;
}

/**
 * The main bootstrap function for the application.
 */
async function bootstrap() {
  console.log('[BOOT] Starting Elep Bootloader...');
  const appRoot = app.getAppPath();
  const config = await loadConfig(appRoot);
  const appContext: AppContext = { config, appRoot };

  const bootloader = new Bootloader(appContext);
  
  bootloader
    .on(LifecycleEvent.BOOTSTRAP, async ({ config, appRoot }, registryLoader) => {
      console.log('[BOOTSTRAP] Initializing registry...');
      let registry: Registry;
      if (config.registry) {
        const registryPath = path.resolve(appRoot, config.registry);
        console.log(`  - Using persistent registry at: ${registryPath}`);
        await fs.mkdir(path.dirname(registryPath), { recursive: true });
        registry = await Registry.createPersistent(registryPath);
      } else {
        console.log('  - Using in-memory registry.');
        registry = await Registry.createMemory();
      }
      registryLoader.load(registry);
    })
    .on(LifecycleEvent.MOUNT_CONTAINERS, async ({ config, appRoot }, containerManager) => {
      console.log('[MOUNT_CONTAINERS] Mounting containers...');
      for (const name in config.containers) {
        const containerConfig = config.containers[name];
        const containerPath = path.resolve(appRoot, containerConfig.path);
        
        console.log(`  - Mounting container '${name}' from '${containerPath}'`);
        await containerManager.mount(name, (bus) => {
          return new FileContainer({
            name,
            bus,
            rootPath: containerPath,
            devMode: !app.isPackaged,
          });
        });
      }
    })
    .on(LifecycleEvent.ATTACH_CORE, async (context, system) => {
      console.log('[ATTACH_CORE] Attaching kernel services...');
      
      const ecore = new ECore(system);
      const kernelApiRouter = createKernelRouter(ecore);
      
      await system.bus.join({
        id: '__kernel',
        groups: ['kernel'],
        apiFactory: () => kernelApiRouter,
      });
      console.log('  - __kernel node attached successfully.');
    })
    .on(LifecycleEvent.RUN, async ({ config }, system) => {
      console.log('[RUN] System is operational. Ensuring plugin states...');
      
      const ensurePlugins = async (pluginUris: string[], groups: string[]) => {
        for (const shortUri of pluginUris) {
          const fullUri = shortUri.startsWith('plugin://') ? shortUri : `plugin://${shortUri.replace(path.sep, '/')}`;
          console.log(`  - Ensuring plugin '${fullUri}' with groups [${groups.join(', ')}]`);
          try {
            await system.plugins.ensure({
              uri: fullUri,
              enable: true,
              groups,
              reconcile: false, // Defer reconciliation to the end of the batch
            });
          } catch (error) {
            console.error(`  - Failed to ensure plugin '${fullUri}':`, error);
          }
        }
      };
      
      await ensurePlugins(config.cores, ['kernel', 'user']);
      await ensurePlugins(config.apps, ['user']);
      
      if (system.shouldReconcile()) {
        console.log('[RUN] Reconciling system state due to changes...');
        await system.reconcile();
      }
      
      console.log('[RUN] System is fully configured and reconciled.');
    });

  const system = await bootloader.start();

  app.on('before-quit', async (event) => {
    event.preventDefault();
    console.log('[SHUTDOWN] Gracefully shutting down system...');
    try {
      await system.shutdown();
    } catch(error) {
      console.error('[SHUTDOWN] Error during system shutdown:', error);
    } finally {
      app.exit();
    }
  });
}

/**
 * Initializes the Electron application lifecycle.
 */
function initializeElectronApp() {
  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit();
    }
  });

  app.whenReady()
    .then(bootstrap)
    .catch((err) => {
      console.error("Fatal error during application startup:", err);
      process.exit(1);
    });
}

initializeElectronApp();