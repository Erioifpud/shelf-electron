import * as fs from 'node:fs/promises';
import * as path from 'node:path';

/**
 * Defines the structure of config.json, with all properties being optional.
 */
export interface AppConfig {
  registry?: string;
  containers?: Record<string, { path: string }>;
  cores?: string[];
  apps?: string[];
}

// A constant holding safe default values for the application configuration.
const DEFAULT_CONFIG: Required<AppConfig> = {
  registry: '', // An empty string signifies an in-memory registry.
  containers: {},
  cores: [],
  apps: [],
};

/**
 * Securely loads, parses, and provides default values for the application configuration.
 * @param appRoot - The absolute root directory of the application.
 * @returns A validated configuration object with all properties guaranteed to be present.
 */
export async function loadConfig(appRoot: string): Promise<Required<AppConfig>> {
  const configPath = path.join(appRoot, 'config.json');
  try {
    const content = await fs.readFile(configPath, 'utf-8');
    const userConfig = JSON.parse(content) as AppConfig;
    
    // Merge user-provided config over the defaults.
    return { ...DEFAULT_CONFIG, ...userConfig };
  } catch (error: any) {
    if (error.code === 'ENOENT') {
      console.warn(`[Config] config.json not found. Using default settings.`);
      return DEFAULT_CONFIG;
    }
    console.error(`[Config] Error reading or parsing config.json:`, error);
    console.warn(`[Config] Using default settings due to error.`);
    return DEFAULT_CONFIG;
  }
}