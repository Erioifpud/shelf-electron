import type { Bus, Node } from "@eleplug/ebus";
import type { PluginManifest } from "@eleplug/esys";
import type { Plugin, PluginActivationContext } from "@eleplug/anvil";
import type { IPluginLoader } from "./plugin-loader.js";
import type { DevPlugin } from "./dev-plugin-types.js";
import * as path from 'node:path';

/**
 * Represents the complete runtime state and lifecycle management for a single activated plugin.
 * It encapsulates the plugin's EBUS Node, its loaded module, and the logic for
 * invoking its activation and deactivation hooks. In development mode, it also manages
 * the lifecycle of the plugin's `DevPlugin` adapter.
 */
export class PluginRuntime {
  private node: Node | null = null;
  private pluginModule: Plugin | null = null;
  public manifest!: PluginManifest;
  
  /**
   * The active development plugin instance for this runtime.
   * This is only populated if the container is running in development mode
   * and the plugin's `elep.config.ts` provides a `dev` export.
   * @public
   */
  public activeDevPlugin: DevPlugin | null = null;

  /**
   * Checks if the plugin is currently active (i.e., has a running EBUS Node).
   * @returns `true` if the plugin is active, otherwise `false`.
   */
  public get isActive(): boolean {
    return this.node !== null;
  }

  /**
   * Creates an instance of PluginRuntime.
   * @param options - The dependencies required for the runtime, including the EBUS bus,
   *                  container context, the plugin loader, and the dev mode flag.
   */
  constructor(
    private readonly options: {
      bus: Bus;
      containerName: string;
      pluginPath: string;
      loader: IPluginLoader;
      /** Indicates if the container is running in development mode. */
      devMode: boolean;
    }
  ) {}

  /**
   * Activates the plugin. This process includes:
   * 1. Loading the plugin's manifest to determine its identity and groups.
   * 2. If in dev mode, loading `elep.config.ts` and starting the `DevPlugin`.
   * 3. Loading the plugin's main module.
   * 4. Joining the EBUS network to create a Node for the plugin using groups from the manifest.
   * 5. Constructing the activation context.
   * 6. Calling the plugin's `activate` method with the context.
   * This method is idempotent; it will do nothing if the plugin is already active.
   *
   * @throws An error if any step of the activation process fails.
   */
  public async activate(): Promise<void> {
    if (this.isActive) {
      console.warn(
        `[PluginRuntime] Plugin at '${this.options.pluginPath}' is already active. Skipping activation.`
      );
      return;
    }

    // 1. Load the plugin's metadata.
    this.manifest = await this.options.loader.loadManifest(
      this.options.pluginPath
    );

    // 2. If in development mode, load the config and start the dev plugin.
    if (this.options.devMode) {
      const config = await this.options.loader.loadConfig(this.options.pluginPath);
      if (config?.dev) {
        this.activeDevPlugin = config.dev;
        
        const pluginAbsolutePath = path.resolve(
          // This relies on the loader having a `rootPath`, which is specific to FilePluginLoader.
          // A more robust solution for multiple loader types might involve a dedicated method.
          (this.options.loader as any).rootPath, this.options.pluginPath
        );

        console.log(`[PluginRuntime] Starting dev plugin for '${this.manifest.name}'...`);
        await this.activeDevPlugin.start({
          pluginUri: `plugin://${this.options.containerName}/${this.options.pluginPath}`,
          pluginAbsolutePath,
        });
      }
    }

    // 3. Load the main plugin module.
    this.pluginModule = await this.options.loader.loadModule(
      this.options.pluginPath,
      this.manifest
    );

    // 4. Create the network identity for the plugin, sourcing groups from the manifest.
    const groups = this.manifest.pluginGroups || [];
    const node = await this.options.bus.join({
      id: this.manifest.name,
      groups, // Use the static groups defined in the plugin's manifest.
    });
    this.node = node; // Set the node immediately to indicate an active state.

    try {
      // 5. Set the plugin's API, which triggers the 'activate' call.
      await node.setApi(async (t) => {
        const context: PluginActivationContext = {
          router: t.router,
          procedure: t.procedure,
          pluginUri: `plugin://${this.options.containerName}/${this.options.pluginPath}`,
          subscribe: node.subscribe.bind(node),
          emiter: node.emiter.bind(node),
          link: (pluginName: string) => node.connectTo(pluginName) as any,
        };
        // 6. The core activation logic is delegated to the plugin itself.
        return this.pluginModule!.activate(context);
      });
    } catch (error) {
      // If activation fails for any reason, perform a full cleanup.
      await this.deactivate();
      throw error; // Re-throw the original error to the caller.
    }
  }

  /**
   * Deactivates the plugin. This process includes:
   * 1. Calling the plugin's `deactivate` hook, if it exists.
   * 2. Stopping the `DevPlugin`, if one is active.
   * 3. Closing the plugin's EBUS Node, gracefully leaving the network.
   * 4. Clearing all internal state.
   * This method is idempotent.
   */
  public async deactivate(): Promise<void> {
    if (!this.isActive) {
      return;
    }

    try {
      // 1. Allow the plugin to perform its own cleanup first.
      await this.pluginModule?.deactivate?.();
      
      // 2. Stop the development plugin if it's running.
      if (this.activeDevPlugin) {
        console.log(`[PluginRuntime] Stopping dev plugin for '${this.manifest.name}'...`);
        await this.activeDevPlugin.stop();
      }

    } catch (err: any) {
      console.error(
        `[PluginRuntime] Error during plugin-specific deactivation for '${this.options.pluginPath}':`,
        err.message
      );
    } finally {
      // 3. Ensure the node is always closed and state is reset,
      //    even if deactivation hooks fail.
      await this.node?.close();
      this.node = null;
      this.pluginModule = null;
      this.activeDevPlugin = null;
    }
  }
}