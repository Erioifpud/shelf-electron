import { ECore } from '@eleplug/elep';
import { pin, initERPC, PIN_FREE_KEY, PIN_ID_KEY, __pin_brand } from '@eleplug/erpc';

/**
 * Creates the erpc Router for the __kernel node.
 * @param ecore - The ECore instance to be pinned and exposed to core plugins.
 * @returns A type-safe erpc Router.
 */
export function createKernelRouter(ecore: ECore) {
  const e = initERPC.create();

  return e.router({
    /**
     * Provides secure access to core Electron functionalities.
     * This procedure can only be called by plugins belonging to the 'kernel' group.
     * @returns {Pin<ECore>} A remote procedure call proxy to the ECore instance.
     */
    core: e.procedure.ask(() => pin(ecore)),
  });
}

/**
 * Infers the exact API type from the router factory function.
 */
export type KernelApi = ReturnType<typeof createKernelRouter>;